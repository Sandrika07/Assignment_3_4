window.addEventListener("load", () => {
    const loader = document.getElementById("loader");
    const mainContent = document.getElementById("main-content");
  
    if (loader && mainContent) {
      loader.style.opacity = "0";
      loader.style.transition = "opacity 1s ease-in-out";
  
      setTimeout(() => {
        loader.style.display = "none";
        mainContent.style.display = "block";
        mainContent.style.opacity = "1";
      }, 1000);
    } else {
      console.error("Loader or main-content element not found!");
    }
  });
  