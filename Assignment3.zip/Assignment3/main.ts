// TypeScript File: main.ts

// Show Loader and Hide it after Page Load
window.addEventListener("load", () => {
  const loader = document.getElementById("loader") as HTMLElement;
  const mainContent = document.getElementById("main-content") as HTMLElement;

  if (!loader || !mainContent) {
    console.error("Loader or Main Content element not found!");
    return;
  }

  // Fade out loader
  loader.style.opacity = "0";
  loader.style.transition = "opacity 1s ease-in-out";

  // Wait for the animation to complete
  setTimeout(() => {
    loader.style.display = "none";
    mainContent.style.display = "block";
    mainContent.style.opacity = "1";
  }, 1000);
});

// Handle Project Click to Show/Hide Details
const projects = document.querySelectorAll(".project");
projects.forEach((project) => {
  project.addEventListener("click", () => {
    const details = project.querySelector(".project-details") as HTMLElement;
    if (details.classList.contains("active")) {
      // Hide details if already visible
      details.classList.remove("active");
    } else {
      // Hide all other project details
      document.querySelectorAll(".project-details").forEach((detail) => {
        detail.classList.remove("active");
      });
      // Show clicked project details
      details.classList.add("active");
    }
  });
});
